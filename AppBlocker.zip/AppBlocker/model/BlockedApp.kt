package com.adam.appblocker.model

data class BlockedApp(
    val packageName: String,
    val appName: String,
    val isActive: Boolean = true,
    val blockMethod: String = "pm_disable"
)
