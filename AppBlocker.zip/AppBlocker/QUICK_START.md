# 🚀 App Lockdown - Быстрый старт

## ⚡ Самый быстрый способ (30 секунд)

### Вариант 1: Через Android Studio

```bash
# 1. Открой Android Studio
# 2. File → New → Project from Version Control
# 3. Введи URL этого репозитория
# 4. Дождись загрузки и синхронизации
# 5. Build → Build Bundle(s) / APK(s) → Build APK(s)
# 6. APK готов в app/build/outputs/apk/debug/
```

### Вариант 2: Через командную строку (Linux/Mac)

```bash
# Клонируй репозиторий
git clone https://github.com/yourusername/AppBlocker.git
cd AppBlocker

# Собери APK
./gradlew assembleDebug

# Установи на устройство
./gradlew installDebug

# Или вручную
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Вариант 3: Windows PowerShell

```powershell
# Собери
.\gradlew.bat assembleDebug

# Установи
adb install -r app\build\outputs\apk\debug\app-debug.apk
```

## 📱 После установки

1. **Открой приложение**
2. **Дай Root доступ**
   - KernelSU Manager → Settings → Superuser
   - Найди "App Lockdown" → Allow
3. **Включи Accessibility Service**
   - Settings → Accessibility → App Lockdown
4. **Нажми "Start Blocking"**

✅ Приложения в списке будут блокироваться автоматически!

## 🎨 Material 3 Expressive дизайн

- ✨ Динамические цвета (если поддерживается)
- 🎭 Большие, выразительные компоненты
- 🌊 Плавные анимации
- 📱 Полностью адаптивный UI

## 🔧 Три метода блокировки

| Метод | Скорость | Надежность | CPU | Описание |
|-------|----------|-----------|-----|---------|
| **pm disable** | Медленно | Высокая | Низкий | Отключает через PM |
| **killall** | Быстро | Средняя | Средний | Убивает процесс |
| **Intercept** | Мгновенно | Высокая | Высокий | Перехватывает запуск |

## 📦 Встроенные приложения для блокировки

```
✅ com.zhiliaoapp.musically (TikTok)
✅ com.facebook.katana (Facebook)
✅ com.instagram.android (Instagram)
```

+ любые другие через "Add Application"

## 🔍 Поиск package name

```bash
adb shell pm list packages | grep -i tiktok
```

Или через интернет: `adb shell dumpsys package com.package.name`

## 📊 Размеры

| Тип | Размер |
|-----|--------|
| Debug APK | ~3.5 MB |
| Release APK | ~1.8 MB |
| Исходный код | ~150 KB |

## ⚙️ Требования

- **Android**: 12+ (API 31+)
- **KernelSU**: Next версия
- **RAM**: 100 MB свободной памяти
- **Root**: Обязателен

## 🛠️ Если что-то не работает

```bash
# Проверь логи
adb logcat | grep "AppBlocker"

# Перезагрузи сервис
adb shell pm disable com.adam.appblocker
adb shell pm enable com.adam.appblocker

# Полностью переустанови
adb uninstall com.adam.appblocker
adb install -r app-debug.apk
```

## 🎯 Advanced опции (в коде)

**Интервал проверки приложений**: Найди в `AppBlockerService.kt`:
```kotlin
delay(1000)  // Измени на 500, 2000 и т.д.
```

**Добавление приложений в код**:
```kotlin
private val blockedPackages = mutableListOf(
    "com.zhiliaoapp.musically",
    "com.facebook.katana",
    "com.example.your_app"  // Добавь сюда
)
```

## 🌐 Обновления

Для добавления новых версий Material Design просто обнови зависимости в `build.gradle`:
```gradle
implementation 'androidx.compose.material3:material3:1.2.0'
```

## 📄 Лицензия

Для личного использования с KernelSU

---

**Всё готово для компиляции! 🎉**

Вопросы → Проверь BUILD_INSTRUCTIONS.md
