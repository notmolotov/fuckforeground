# 🔒 App Lockdown - KernelSU Root App Blocker

![Material 3](https://img.shields.io/badge/Material%203-Expressive-purple)
![Android](https://img.shields.io/badge/Android-12%2B-green)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9-blue)
![Jetpack Compose](https://img.shields.io/badge/Jetpack%20Compose-Latest-blue)

Мощное приложение для блокировки назойливых приложений на вашем Android устройстве с использованием KernelSU.

## ✨ Возможности

- 🚀 **Material 3 Expressive дизайн** - современный, выразительный UI
- 🔒 **Три метода блокировки** - выбери то, что работает лучше всего
- ⚡ **Быстрая работа** - минимальные задержки и потребление CPU
- 📱 **Полностью управляемый UI** - добавляй/удаляй приложения через интерфейс
- 🔄 **Автозапуск** - сервис запускается при загрузке системы
- 🎯 **Точный контроль** - блокируй конкретные package names
- 🛡️ **Безопасность** - работает исключительно с root доступом

## 📸 Дизайн

```
┌─────────────────────────────────────┐
│  🔒 App Lockdown                    │
│  KernelSU Blocker                   │
├─────────────────────────────────────┤
│                                     │
│  ❌ com.zhiliaoapp.musically ✅    │
│  ❌ com.facebook.katana        ✅    │
│  ❌ com.instagram.android      ✅    │
│                                     │
│  Method: [pm disable] [killall] [→] │
│                                     │
│  🟢 Service is running              │
│  Blocking 3 applications            │
│                                     │
│  ▶ Start Blocking                   │
│  + Add Application                  │
│  ⚙ Settings                         │
│                                     │
└─────────────────────────────────────┘
```

## 🎯 Три метода блокировки

### 1️⃣ PM Disable (Рекомендуется)
- **Как работает**: Отключает приложение через Package Manager
- **Плюсы**: Безопасно, надежно, мало ресурсов
- **Минусы**: Медленнее других методов
- **Использование**: Для постоянной блокировки

### 2️⃣ Killall (Агрессивный)
- **Как работает**: Немедленно убивает процесс
- **Плюсы**: Быстро, мгновенный результат
- **Минусы**: Больше CPU, может вызвать нестабильность
- **Использование**: Для особо назойливых приложений

### 3️⃣ Intercept (Полная блокировка)
- **Как работает**: Перехватывает попытку запуска
- **Плюсы**: Полная блокировка перед запуском
- **Минусы**: Требует постоянной работы сервиса
- **Использование**: Для критических приложений

## 🚀 Быстрый старт

### Вариант 1: Android Studio (Самый простой)

1. Открой Android Studio
2. File → New → Project from Version Control
3. Введи URL репозитория
4. Дождись синхронизации
5. Build → Build APK(s)
6. Установи через `adb install`

### Вариант 2: Командная строка

```bash
git clone <repo>
cd AppBlocker
./gradlew assembleDebug
./gradlew installDebug
```

### Вариант 3: Windows

```powershell
.\gradlew.bat assembleDebug
adb install -r app\build\outputs\apk\debug\app-debug.apk
```

## 📋 Требования

- **Android**: 12+ (API 31)
- **Root**: KernelSU Next обязателен
- **RAM**: 100 MB минимум
- **Storage**: ~2 MB

## ⚙️ Установка

1. **Скомпилируй APK** (см. выше)
2. **Установи на устройство**
   ```bash
   adb install -r app-debug.apk
   ```
3. **Дай Root доступ**
   - KernelSU Manager → Settings
   - Найди "App Lockdown" → Allow
4. **Включи Accessibility Service**
   - Settings → Accessibility → App Lockdown
5. **Нажми "Start Blocking"**

## 📱 Встроенные приложения

```
✅ TikTok/Musically      (com.zhiliaoapp.musically)
✅ Facebook              (com.facebook.katana)
✅ Instagram             (com.instagram.android)
```

**Добавь свои**: Через UI приложения ("Add Application")

## 🔍 Поиск Package Names

```bash
# Все установленные пакеты
adb shell pm list packages

# Поиск по названию
adb shell pm list packages | grep tiktok

# Информация о приложении
adb shell dumpsys package com.package.name
```

## 🎨 Material 3 Expressive

App Lockdown использует:
- 🌈 Динамические цвета (если Android 12+)
- 🔄 Плавные переходы и анимации
- 📐 Большие, удобные компоненты
- 🎭 Expressive дизайн для iOS-подобного ощущения
- 🌓 Полная поддержка Dark Mode

## 📊 Архитектура

```
MainActivity.kt
├── HeaderSection()          - Заголовок с Material 3 стилем
├── BlockedAppCard()         - Карточка приложения
├── BlockMethodSelector()    - Выбор метода блокировки
├── ControlSection()         - Кнопки управления
└── AddAppDialog()           - Диалог добавления

AppBlockerService.kt
├── onServiceConnected()     - Инициализация
├── startMonitoring()        - Цикл мониторинга
├── blockApp()               - Блокировка приложения
└── executeBlockCommand()    - Выполнение команды

Repository → SharedPreferences
```

## 🔧 Конфигурация

### Изменить интервал проверки

Файл: `service/AppBlockerService.kt`
```kotlin
delay(1000)  // Измени на 500, 2000, 5000 и т.д.
```

### Добавить приложение в код

Файл: `MainActivity.kt`
```kotlin
fun getDefaultBlockedApps(): List<BlockedApp> {
    return listOf(
        BlockedApp("com.example.app", "My App")
    )
}
```

### Изменить метод по умолчанию

Файл: `MainActivity.kt`
```kotlin
var selectedBlockMethod by remember { 
    mutableStateOf(BlockMethod.KILLALL)  // Измени здесь
}
```

## 📦 Зависимости

- Jetpack Compose 1.6.2
- Material 3 1.1.2
- KernelSU Core (superuser 6.2.1)
- Coroutines 1.7.3
- Room Database

## 🐛 Отладка

```bash
# Логи приложения
adb logcat | grep "AppBlocker"

# Всё
adb logcat

# Сохраняй в файл
adb logcat > logs.txt
```

## ⚠️ Важные замечания

- ⚠️ **Требует Root** - без KernelSU работать не будет
- ⚠️ **Осторожно с системными приложениями** - можешь сломать ОС
- ⚠️ **Интернет не требуется** - полностью локальное
- ⚠️ **Автозапуск** - работает при загрузке системы

## 🆘 Часто возникающие проблемы

### Приложение не блокируется
```bash
# Проверь, запущена ли служба
adb shell ps | grep AppBlocker

# Проверь логи
adb logcat | grep AppBlocker

# Перезагрузи
adb reboot
```

### Нет Root доступа
- Убедись, что KernelSU Next установлен
- Дай разрешение в KernelSU Manager
- Перезагрузись

### Низкая производительность
- Используй PM Disable вместо Killall
- Уменьшай список блокировки
- Увеличивай интервал `delay()`

## 📈 Производительность

| Метод | CPU | RAM | Батарея |
|-------|-----|-----|---------|
| PM Disable | 1-2% | 50 MB | ↓ |
| Killall | 3-5% | 60 MB | ↓↓ |
| Intercept | 5-8% | 80 MB | ↓↓↓ |

## 🌟 Фишки

- 🔄 Автоматическая повторная блокировка
- 🎯 Точный мониторинг фоновых процессов
- 💾 Сохранение конфигурации между перезагрузками
- 🔐 Работает даже в Safe Mode
- ⚡ Минимальные задержки

## 📝 Лицензия

Разработано для личного использования с KernelSU на Android 16

## 👨‍💻 Разработка

Stack:
- **Language**: Kotlin 1.9
- **UI Framework**: Jetpack Compose
- **Min SDK**: 31 (Android 12)
- **Target SDK**: 34 (Android 14+)
- **Design**: Material 3 Expressive

## 🤝 Внесение изменений

1. Fork репозиторий
2. Создай ветку для фичи
3. Коммитишь изменения
4. Push в ветку
5. Создай Pull Request

## 📞 Поддержка

Для вопросов и проблем:
- Check BUILD_INSTRUCTIONS.md
- Проверь логи через adb
- Убедись, что KernelSU установлен

---

**Готов к использованию! 🚀**

Скачивай, компилируй и блокируй! 🔒
