package com.adam.appblocker

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adam.appblocker.data.AppBlockerRepository
import com.adam.appblocker.model.BlockedApp
import com.adam.appblocker.service.AppBlockerService
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        Shell.getShell { shell ->
            setContent {
                AppBlockerTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        AppBlockerScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun AppBlockerScreen() {
    val scope = rememberCoroutineScope()
    var blockedApps by remember { mutableStateOf<List<BlockedApp>>(emptyList()) }
    var selectedBlockMethod by remember { mutableStateOf(BlockMethod.PM_DISABLE) }
    var serviceRunning by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        blockedApps = getDefaultBlockedApps()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header with Material 3 Expressive style
        HeaderSection()

        // Blocked apps list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(blockedApps) { app ->
                BlockedAppCard(app, selectedBlockMethod)
            }
        }

        Divider(modifier = Modifier.padding(horizontal = 16.dp))

        // Block method selector
        BlockMethodSelector(
            selectedMethod = selectedBlockMethod,
            onMethodSelected = { selectedBlockMethod = it }
        )

        Divider(modifier = Modifier.padding(horizontal = 16.dp))

        // Control buttons
        ControlSection(
            onStartService = {
                serviceRunning = true
                startBlockerService()
            },
            onAddApp = { showAddDialog = true },
            serviceRunning = serviceRunning,
            appCount = blockedApps.size
        )
    }

    if (showAddDialog) {
        AddAppDialog(
            onDismiss = { showAddDialog = false },
            onAppAdded = { newApp ->
                blockedApps = blockedApps + newApp
                showAddDialog = false
            }
        )
    }
}

@Composable
fun HeaderSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = androidx.compose.foundation.background(
                    MaterialTheme.colorScheme.primaryContainer
                ).brush,
                shape = RoundedCornerShape(bottomEnd = 28.dp, bottomStart = 28.dp)
            )
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Lock,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Column {
                Text(
                    "App Lockdown",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    "KernelSU Blocker",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun BlockedAppCard(app: BlockedApp, method: BlockMethod) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App icon background
            Surface(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(14.dp)),
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    app.packageName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    app.appName,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Method: ${method.displayName}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                )
            }

            // Status badge
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp)),
                color = MaterialTheme.colorScheme.successContainer,
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSuccessContainer
                    )
                    Text(
                        "Active",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSuccessContainer
                    )
                }
            }
        }
    }
}

@Composable
fun BlockMethodSelector(
    selectedMethod: BlockMethod,
    onMethodSelected: (BlockMethod) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text(
            "Block method",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MethodButton(
                method = BlockMethod.PM_DISABLE,
                isSelected = selectedMethod == BlockMethod.PM_DISABLE,
                onClick = { onMethodSelected(BlockMethod.PM_DISABLE) },
                modifier = Modifier.weight(1f)
            )

            MethodButton(
                method = BlockMethod.KILLALL,
                isSelected = selectedMethod == BlockMethod.KILLALL,
                onClick = { onMethodSelected(BlockMethod.KILLALL) },
                modifier = Modifier.weight(1f)
            )

            MethodButton(
                method = BlockMethod.INTERCEPT,
                isSelected = selectedMethod == BlockMethod.INTERCEPT,
                onClick = { onMethodSelected(BlockMethod.INTERCEPT) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MethodButton(
    method: BlockMethod,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
            else
                MaterialTheme.colorScheme.surface
        ),
        border = if (isSelected)
            androidx.compose.foundation.border(
                width = 2.dp,
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(16.dp)
            )
        else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp)),
                color = method.color.copy(alpha = 0.2f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = method.icon,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = method.color
                    )
                }
            }

            Text(
                method.displayName,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun ControlSection(
    onStartService: () -> Unit,
    onAddApp: () -> Unit,
    serviceRunning: Boolean,
    appCount: Int
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Status card
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = if (serviceRunning)
                    MaterialTheme.colorScheme.tertiaryContainer
                else
                    MaterialTheme.colorScheme.errorContainer
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(RoundedCornerShape(50.dp)),
                    color = if (serviceRunning)
                        MaterialTheme.colorScheme.onTertiaryContainer
                    else
                        MaterialTheme.colorScheme.onErrorContainer,
                    shape = RoundedCornerShape(50.dp)
                ) {}

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        if (serviceRunning) "Service is running" else "Service stopped",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        "Blocking $appCount applications",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onBackgroundVariant,
                        alpha = 0.7f
                    )
                }
            }
        }

        // Buttons
        Button(
            onClick = onStartService,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Icon(
                imageVector = Icons.Rounded.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.onPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Start Blocking",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        OutlinedButton(
            onClick = onAddApp,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Add,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Add Application")
        }
    }
}

@Composable
fun AddAppDialog(
    onDismiss: () -> Unit,
    onAppAdded: (BlockedApp) -> Unit
) {
    var packageName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Text("Add application", fontWeight = FontWeight.Bold)
        },
        text = {
            TextField(
                value = packageName,
                onValueChange = { packageName = it },
                placeholder = { Text("com.example.app") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (packageName.isNotBlank()) {
                        onAppAdded(BlockedApp(packageName, packageName.substringAfterLast(".")))
                    }
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AppBlockerTheme(content: @Composable () -> Unit) {
    val colorScheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        MaterialTheme.colorScheme
    } else {
        lightColorScheme()
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

fun startBlockerService() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val intent = Intent(context, AppBlockerService::class.java)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
    } else {
        context.startService(intent)
    }
}

fun getDefaultBlockedApps(): List<BlockedApp> {
    return listOf(
        BlockedApp("com.zhiliaoapp.musically", "TikTok/Musically"),
        BlockedApp("com.facebook.katana", "Facebook"),
        BlockedApp("com.instagram.android", "Instagram")
    )
}

enum class BlockMethod(
    val displayName: String,
    val icon: androidx.compose.material.icons.Icons,
    val color: Color
) {
    PM_DISABLE("pm disable", Icons.Rounded.Settings, Color(0xFF6750A4)),
    KILLALL("killall", Icons.Rounded.Warning, Color(0xFFFFC107)),
    INTERCEPT("Intercept", Icons.Rounded.Block, Color(0xFFD32F2F))
}
