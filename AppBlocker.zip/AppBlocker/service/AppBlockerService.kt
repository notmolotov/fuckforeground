package com.adam.appblocker.service

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.*
import timber.log.Timber

class AppBlockerService : AccessibilityService() {

    private val blockedPackages = mutableListOf(
        "com.zhiliaoapp.musically",
        "com.facebook.katana",
        "com.instagram.android"
    )

    private val handler = Handler(Looper.getMainLooper())
    private var monitoringJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    override fun onServiceConnected() {
        super.onServiceConnected()
        Timber.d("AppBlockerService connected")
        startMonitoring()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            if (blockedPackages.contains(packageName)) {
                blockApp(packageName)
            }
        }
    }

    override fun onInterrupt() {
        Timber.d("Service interrupted")
    }

    private fun startMonitoring() {
        monitoringJob = scope.launch {
            while (isActive) {
                try {
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val tasks = am.getRunningTasks(1)
                    
                    if (tasks.isNotEmpty()) {
                        val topApp = tasks[0].topActivity?.packageName ?: ""
                        if (blockedPackages.contains(topApp)) {
                            blockApp(topApp)
                        }
                    }
                } catch (e: Exception) {
                    Timber.e(e, "Error in monitoring")
                }
                delay(1000)
            }
        }
    }

    private fun blockApp(packageName: String) {
        scope.launch {
            try {
                executeBlockCommand(packageName)
            } catch (e: Exception) {
                Timber.e(e, "Error blocking $packageName")
            }
        }
    }

    private fun executeBlockCommand(packageName: String) {
        Shell.cmd(
            "pm disable-user --user 0 $packageName",
            "killall -9 $packageName"
        ).submit { result ->
            Timber.d("Blocked: $packageName, Code: ${result.code}")
        }
    }

    fun addBlockedApp(packageName: String) {
        if (!blockedPackages.contains(packageName)) {
            blockedPackages.add(packageName)
            Timber.d("Added to block list: $packageName")
        }
    }

    fun removeBlockedApp(packageName: String) {
        blockedPackages.remove(packageName)
        Timber.d("Removed from block list: $packageName")
    }

    override fun onDestroy() {
        super.onDestroy()
        monitoringJob?.cancel()
        scope.cancel()
        Timber.d("AppBlockerService destroyed")
    }
}
