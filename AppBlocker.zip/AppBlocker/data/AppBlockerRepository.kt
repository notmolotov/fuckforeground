package com.adam.appblocker.data

import android.content.Context
import android.content.SharedPreferences
import com.adam.appblocker.model.BlockedApp
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class AppBlockerRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "app_blocker_prefs",
        Context.MODE_PRIVATE
    )

    fun saveBlockedApps(apps: List<BlockedApp>) {
        val json = Json.encodeToString(apps)
        prefs.edit().putString("blocked_apps", json).apply()
    }

    fun getBlockedApps(): List<BlockedApp> {
        val json = prefs.getString("blocked_apps", "[]") ?: "[]"
        return try {
            Json.decodeFromString<List<BlockedApp>>(json)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addBlockedApp(app: BlockedApp) {
        val apps = getBlockedApps().toMutableList()
        apps.add(app)
        saveBlockedApps(apps)
    }

    fun removeBlockedApp(packageName: String) {
        val apps = getBlockedApps().filter { it.packageName != packageName }
        saveBlockedApps(apps)
    }

    fun setBlockMethod(method: String) {
        prefs.edit().putString("block_method", method).apply()
    }

    fun getBlockMethod(): String {
        return prefs.getString("block_method", "pm_disable") ?: "pm_disable"
    }

    fun isServiceRunning(): Boolean {
        return prefs.getBoolean("service_running", false)
    }

    fun setServiceRunning(running: Boolean) {
        prefs.edit().putBoolean("service_running", running).apply()
    }
}
