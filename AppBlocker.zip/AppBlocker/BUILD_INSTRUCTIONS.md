# App Lockdown APK - Build Instructions

## Требования
- Android Studio 2023.x или выше
- JDK 17+
- KernelSU Next установлен на устройстве
- Минимум Android 12 (API 31)

## Структура проекта

```
AppBlocker/
├── build.gradle              # Build конфигурация
├── AndroidManifest.xml       # Манифест приложения
├── MainActivity.kt           # UI на Jetpack Compose
├── model/
│   └── BlockedApp.kt        # Data model
├── service/
│   └── AppBlockerService.kt # Основной сервис блокировки
├── data/
│   └── AppBlockerRepository.kt # Хранилище данных
├── receiver/
│   └── BootReceiver.kt      # Запуск при загрузке
└── res/
    └── values/
        └── strings.xml      # Строки ресурсов
```

## Метод 1: Компиляция в Android Studio

1. **Создай новый проект**
   - File → New → New Android Project
   - Выбери "Empty Activity"
   - Package: `com.adam.appblocker`
   - Language: Kotlin
   - Min SDK: API 31

2. **Замени файлы**
   - Скопируй содержимое каждого .kt файла в соответствующие пакеты
   - Замени build.gradle на предоставленный
   - Замени AndroidManifest.xml
   - Добавь XML ресурсы

3. **Синхронизируй проект**
   - File → Sync Now
   - Дождись загрузки зависимостей

4. **Собери APK**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - APK будет в: `app/build/outputs/apk/debug/`

5. **Установи на устройство**
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## Метод 2: Использование Gradle из командной строки

```bash
cd AppBlocker

# Собери APK
./gradlew assembleDebug

# Установи APK
./gradlew installDebug
```

## Метод 3: Compile командой (быстро)

```bash
kotlinc -d build/classes \
    MainActivity.kt \
    model/BlockedApp.kt \
    service/AppBlockerService.kt \
    data/AppBlockerRepository.kt \
    receiver/BootReceiver.kt
```

## Конфигурация KernelSU

После установки приложения:

1. **Открой KernelSU Manager**
2. **Перейди в Settings → Superuser**
3. **Найди "App Lockdown"**
4. **Дай ему Root доступ**

## Первый запуск

1. Откройся приложение
2. Нажми "Start Blocking"
3. Включи Accessibility Service, когда система попросит
4. Приложения из списка будут блокироваться автоматически

## Добавление приложений

1. В приложении нажми "Add Application"
2. Введи package name (например: `com.example.app`)
3. Нажми "Add"
4. Приложение добавится в список блокировки

## Методы блокировки

### PM Disable (Безопасный)
- Отключает приложение через PackageManager
- Минимальное потребление ресурсов
- Реверсивно (можно включить обратно)

### Killall (Агрессивный)
- Убивает процесс сразу
- Для особо назойливых приложений
- Работает быстро

### Intercept (Полная блокировка)
- Перехватывает запуск приложения
- Предотвращает фоновый запуск
- Требует постоянной работы сервиса

## Поиск Package Names

```bash
# Через adb
adb shell pm list packages | grep app_name

# Примеры популярных приложений:
# TikTok: com.zhiliaoapp.musically
# Facebook: com.facebook.katana
# Instagram: com.instagram.android
# Telegram: org.telegram.messenger
# WhatsApp: com.whatsapp
```

## Логирование и отладка

Логи доступны через:
```bash
adb logcat | grep "AppBlocker"
```

## Проблемы и решения

**Приложение не блокируется:**
- Проверь, есть ли Root доступ
- Убедись, что Accessibility Service включен
- Перезагрузи устройство

**Сервис не запускается:**
- Проверь, установлены ли все разрешения
- Убедись в наличии KernelSU Next
- Пересоби приложение

**Низкая производительность:**
- Используй PM Disable вместо Killall
- Сократи список блокируемых приложений
- Увеличь интервал проверки в коде

## Компиляция Release версии

```bash
./gradlew assembleRelease

# Подпиши APK (нужен ключ)
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
    -keystore debug.keystore \
    app/build/outputs/apk/release/app-release-unsigned.apk \
    android_debug_key

# Оптимизируй
zipalign -v 4 \
    app/build/outputs/apk/release/app-release-unsigned.apk \
    AppLockdown.apk
```

## Размер APK

- Debug: ~3-4 MB
- Release (optimized): ~1.5-2 MB

## Совместимость

- Min SDK: 31 (Android 12)
- Target SDK: 34 (Android 14)
- Tested: Android 14-16

## Лицензия

Для личного использования с KernelSU root

---

**Готов к компиляции!** 🚀

Если возникнут ошибки, проверь:
1. Версию Java (должна быть 17+)
2. Синхронизацию Gradle
3. Версии зависимостей в build.gradle
